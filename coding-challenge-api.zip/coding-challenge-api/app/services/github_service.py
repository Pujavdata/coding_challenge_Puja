from flask import current_app
import requests

GITHUB_API_URL = "https://api.github.com/users/"

def fetch_user_profile(username):
    response = requests.get(f"{GITHUB_API_URL}{username}")
    if response.status_code == 200:
        return response.json()
    return None

def fetch_user_repositories(username):
    response = requests.get(f"{GITHUB_API_URL}{username}/repos")
    if response.status_code == 200:
        return response.json()
    return None