from flask import request
import requests

def fetch_user_profile(username):
    url = f"https://api.bitbucket.org/2.0/users/{username}"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json()
    return None

def fetch_user_repositories(username):
    url = f"https://api.bitbucket.org/2.0/repositories/{username}"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json().get('values', [])
    return []