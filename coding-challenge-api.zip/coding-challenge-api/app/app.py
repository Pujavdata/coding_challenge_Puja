from flask import Flask
from app.routers.profile_router import profile_router

def create_app():
    app = Flask(__name__)
    
    # Register routers
    app.register_blueprint(profile_router)

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)