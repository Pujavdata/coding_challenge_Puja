from flask import Flask

def create_app():
    app = Flask(__name__)

    from app.routers.profile_router import profile_router
    app.register_blueprint(profile_router)

    return app

app = create_app()