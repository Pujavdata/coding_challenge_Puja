from flask import Blueprint, jsonify
from app.services.github_service import fetch_user_profile as fetch_github_profile
from app.services.bitbucket_service import fetch_user_profile as fetch_bitbucket_profile

profile_router = Blueprint('profile', __name__)

@profile_router.route('/profile/github/<username>', methods=['GET'])
def get_github_profile(username):
    profile_data = fetch_github_profile(username)
    if profile_data:
        return jsonify(profile_data), 200
    return jsonify({"error": "GitHub user not found"}), 404

@profile_router.route('/profile/bitbucket/<username>', methods=['GET'])
def get_bitbucket_profile(username):
    profile_data = fetch_bitbucket_profile(username)
    if profile_data:
        return jsonify(profile_data), 200
    return jsonify({"error": "Bitbucket user not found"}), 404