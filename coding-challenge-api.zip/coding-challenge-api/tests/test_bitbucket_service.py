from flask import jsonify
import unittest
from app.services.bitbucket_service import fetch_user_profile

class TestBitbucketService(unittest.TestCase):

    def test_fetch_user_profile_valid(self):
        username = "valid_username"
        profile_data = fetch_user_profile(username)
        self.assertIsNotNone(profile_data)
        self.assertIn('username', profile_data)
        self.assertEqual(profile_data['username'], username)

    def test_fetch_user_profile_invalid(self):
        username = "invalid_username"
        profile_data = fetch_user_profile(username)
        self.assertIsNone(profile_data)

if __name__ == '__main__':
    unittest.main()