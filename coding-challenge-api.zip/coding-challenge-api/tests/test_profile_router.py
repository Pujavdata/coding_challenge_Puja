from flask import json
from app import app
from app.services.github_service import fetch_user_profile
from app.services.bitbucket_service import fetch_bitbucket_profile

def test_get_profile_github(mocker):
    mocker.patch('app.services.github_service.fetch_user_profile', return_value={'username': 'testuser', 'profile_url': 'https://github.com/testuser'})
    client = app.test_client()
    response = client.get('/profile/testuser')
    assert response.status_code == 200
    assert response.json == {'username': 'testuser', 'profile_url': 'https://github.com/testuser'}

def test_get_profile_bitbucket(mocker):
    mocker.patch('app.services.bitbucket_service.fetch_bitbucket_profile', return_value={'username': 'testuser', 'profile_url': 'https://bitbucket.org/testuser'})
    client = app.test_client()
    response = client.get('/profile/testuser')
    assert response.status_code == 200
    assert response.json == {'username': 'testuser', 'profile_url': 'https://bitbucket.org/testuser'}

def test_get_profile_not_found(mocker):
    mocker.patch('app.services.github_service.fetch_user_profile', return_value=None)
    client = app.test_client()
    response = client.get('/profile/nonexistentuser')
    assert response.status_code == 404
    assert response.json == {"error": "User not found"}