from flask import jsonify
import pytest
from app.services.github_service import fetch_user_profile

def test_fetch_user_profile(mocker):
    # Mocking the response from GitHub API
    mock_response = {
        "login": "octocat",
        "id": 1,
        "avatar_url": "https://github.com/images/error/octocat_happy.gif",
        "html_url": "https://github.com/octocat",
        "name": "Octo Cat",
        "public_repos": 2,
        "followers": 20,
        "following": 0
    }
    
    mocker.patch('app.services.github_service.requests.get', return_value=mocker.Mock(status_code=200, json=lambda: mock_response))
    
    profile = fetch_user_profile("octocat")
    
    assert profile == mock_response

def test_fetch_user_profile_not_found(mocker):
    # Mocking a 404 response from GitHub API
    mocker.patch('app.services.github_service.requests.get', return_value=mocker.Mock(status_code=404))
    
    profile = fetch_user_profile("nonexistentuser")
    
    assert profile is None