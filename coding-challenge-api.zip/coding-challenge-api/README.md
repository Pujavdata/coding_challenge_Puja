# coding-challenge-api

## Overview
This project is a Flask application that aggregates user profile data from GitHub and Bitbucket APIs. It provides a simple interface to retrieve user profiles and their associated repositories.

## Project Structure
```
coding-challenge-api
├── app
│   ├── __init__.py
│   ├── app.py
│   ├── routers
│   │   ├── __init__.py
│   │   └── profile_router.py
│   └── services
│       ├── __init__.py
│       ├── github_service.py
│       └── bitbucket_service.py
├── tests
│   ├── __init__.py
│   ├── test_github_service.py
│   ├── test_bitbucket_service.py
│   └── test_profile_router.py
├── requirements.txt
└── README.md
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd coding-challenge-api
   ```
3. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage
To run the application, execute the following command:
```
python app/app.py
```
The application will start on `http://127.0.0.1:5000`.

## API Endpoints
### Get User Profile
- **Endpoint:** `/profile/<username>`
- **Method:** `GET`
- **Description:** Fetches the user profile from GitHub and Bitbucket based on the provided username.
- **Response:**
  - **200 OK:** Returns user profile data.
  - **404 Not Found:** Returns an error message if the user is not found.

## Testing
To run the tests, use the following command:
```
pytest
```

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License
This project is licensed under the MIT License.